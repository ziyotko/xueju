Component({
  properties: {
    event: {
      type: Object,
      value: {}
    }
  },

  methods: {
    onCardTap() {
      this.triggerEvent("cardtap", { id: this.data.event.id })
    },

    onJoinTap() {
      this.triggerEvent("jointap", { id: this.data.event.id })
    }
  }
})
